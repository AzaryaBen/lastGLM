TEMPLATE BUKU TUGAS AKHIR VERSI 1.1

Disusun tanggal 9 Januari 2024.

Terakhir diedit 14 Mei 2024.

Editor pertama (dan saat ini): Kevin Christ Aditya (AK20)

Disclaimer: Template ini diadaptasi dari Template Buku TA Prodi Fisika ITB, dengan penyesuaian yang berpedoman pada penulisan TA Prodi Matematika dan Aktuaria ITB.

=============================================================================
RELEASE NOTES
Catatan perubahan pada v1.1.

Setelah beberapa umpan balik dari pengguna tahun pertama template ini, beberapa perubahan dilakukan:

1. Persamaan matematika secara default akan tercetak di tengah. Bagi pengguna yang tetap menginginkan persamaan tercetak menjorok ke kiri sebagaimana pada v1.0, tambahkan opsi 'fleqn' pada \documentclass.

2. Masalah atas spacing horizontal pada daftar gambar dan daftar isi sudah diperbaiki (lihat perintah \cftfignumwidth dan \cfttabnumwidth pada 'pengaturan.tex').

3. Performa algoritma pemenggalan kata untuk bahasa Indonesia sudah ditingkatkan. Apabila masih terdapat masalah, gunakan pemenggalan manual: \hyphenation{pe meng gal an} pada badan teks.

4. Tambahan gaya pembubuhan referensi. Untuk kustomisasi gaya pembubuhan referensi, gunakan perintah \setcitestyle. Rujuk package 'natbib' untuk informasi lebih lanjut.

Terima kasih atas pengguna template yang sudah memberikan feedback dan solusi.

=============================================================================

GETTING STARTED

Pada pengaturan Overleaf (Menu) di ujung kiri atas, ubah opsi 'Main document' menjadi 'main.tex'.

Isilah identitas pada Umum > 1. identitas.tex.

Template ini terdiri dari tiga bab besar: Awal, Badan, dan Akhir. File .tex masing2 komponen buku sudah disediakan, tambahkan/kurangkan sesuai kebutuhan. Masukkan naskah Tugas Akhir Anda di file-file yang sudah disediakan pada folder Bagian.

Daftar isi, daftar gambar, daftar tabel dibangkitkan secara otomatis. Lengkapi buku TA Anda dengan daftar notasi dan daftar simbol, apabila diperlukan. 

Tambahkan resource yang Anda butuhkan pada folder Gambar.

Template contoh daftar (list), gambar, dan tabel disediakan.

Isikan daftar pustaka pada Umum > pustaka.bib. Sudah disediakan template untuk masing-masing jenis sitasi. Style default pada template ini adalah APA style (apalike). Rujuk https://overleaf.com/learn/latex/Bibtex_bibliography_styles untuk style lainnya.

Rujuk masing-masing .tex untuk pedoman lebih lanjut.

=============================================================================

Catatan:
1. Untuk kemudahan, disarankan template buku TA ini di-compile melalui Overleaf.

2. Jika ada pertanyaan, saran, atau menemukan bug, hubungi: (WA) 082312149711, (LINE) adit_kevinchrist

3. Selamat meng-TA :)